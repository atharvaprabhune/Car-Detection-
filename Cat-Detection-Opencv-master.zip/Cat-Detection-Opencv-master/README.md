# Cat😺 Face Detection using OpenCV

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)                 
[![Python 3.6](https://img.shields.io/badge/python-3.6-blue.svg)](https://www.python.org/downloads/release/python-360/)   

## [Follow us on Instagram for Machine Learning Guidelines & Path](https://www.instagram.com/machine_learning_hub.ai/)
## [Watch Tutorial Videos of these all projects](https://www.youtube.com/c/MachineLearningHub)
## [Buy Python & ML projects for students at lower rate](https://www.instamojo.com/kushalbhavsar1820)

## Usage:-

- Clone my repository.
- Open CMD in working directory.
- Run `cat_det.py`.

## Screenshots

<img src="https://github.com/Spidy20/Cat-Detection-Opencv/blob/master/CD_t1.jpg">
<img src="https://github.com/Spidy20/Cat-Detection-Opencv/blob/master/CD_t2.jpg">
<img src="https://github.com/Spidy20/Cat-Detection-Opencv/blob/master/CD_t3.jpg">
<img src="https://github.com/Spidy20/Cat-Detection-Opencv/blob/master/CD_t5.jpg">


## Just follow☝️ me and Star⭐ my repository 

# [Buy me a Coffee☕](https://www.buymeacoffee.com/spidy20)
## [Donate me on PayPal(It will inspire me to do more projects)](https://www.paypal.me/spidy1820)
## Donate me on GPAY:- kushalbhavsar58-1@okaxis
